Hi! Thanks for downloading my 1bit asset pack for controller/keyboard prompts

I hope you enjoy it, if there's anything you need that isn't included leave a comment!
Follow me on twitter! @retryeli

Credit isn't necessary but it is appreciated!